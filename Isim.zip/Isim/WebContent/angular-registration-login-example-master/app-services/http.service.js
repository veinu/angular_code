(function () {
    'use strict';

    angular
        .module('app')
        .factory('HttpService', HttpService);

    HttpService.$inject = ['$http'];
    function HttpService($http) {
        var httpservice = {};

        httpservice.Get = Get;

        return httpservice;

        function Get(url, callback) {
            $http.get(url).then(
		  			  function (response) {
		  				  alert("in get call" + " " +  response.data + response.status);
		  				 callback(response);
		      }, function (error) {
				   alert("Error .." + error.status);

				  }); 

        }


    }

   

})();