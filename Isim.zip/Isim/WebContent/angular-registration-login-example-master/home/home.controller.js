﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['UserService', 'HttpService' ,'$rootScope'];
    function HomeController(UserService,HttpService, $rootScope) {
        var vm = this;
        
        vm.search = search;
        vm.username1 = "";
        vm.user = null;
        vm.allUsers = [];
        vm.deleteUser = deleteUser;
        vm.data = "";
        

        function search(){
        	alert("clicked Search");
        	vm.personID = btoa(vm.personID);
        	
        	vm.authToken = $rootScope.globals.currentUser.authToken;
        	alert("vm.personID : " + vm.authToken);
        	vm.authToken = 	vm.authToken.replace(new RegExp("\\+","g"),'%2B');
        	vm.authToken = 	vm.authToken.replace(new RegExp("\\/","g"),'%2F');
        	
        	var url1 = 'http://10.11.30.16:9080/ISIM_PSL/rest/Identity/' + vm.personID + '/accounts/'+ vm.authToken;
        	alert ("url is : " + url1);
        	var url = 'http://10.11.30.16:9080/ISIM_PSL/rest/Identity/ZXJnbG9iYWxpZD0wMDAwMDAwMDAwMDAwMDAwMDAwNyxvdT0wLG91PXBlb3BsZSxlcmdsb2JhbGlkPTAwMDAwMDAwMDAwMDAwMDAwMDAwLG91PWlibSxEQz1DT00%3D/accounts/ANSSrrxREhxLeoEA3xuL7jFLRWeasV9Ochu0%2FoMvixHssrmqoejanoRJg7cNEaMGZfD2ribUut5G19XEew%2FD2dvez7Rg%2Fh0dPJTm6%2Fl7vgcEAdstx7aiaDePW0Tjfeq0U%2FxkiIT3iUHTGm0q7%2FbVeBPfavQ5F27Lmmaspi2R5RdSktJk3vKuZ%2Fr2Y4HaSVoz5PVwIALuZ3byNS9oVMyxdjwXFgZ9LB6dKcNAUjpHUivyVoy%2BR9SoXF1nfviAvp3iU0iv7hY2qCcRimqpWAe5oI8vt6vv%2FakZh4g2XG%2FvpuI0hQa8%2BxfIJ%2Fhj9y5Z23gdi8EaurjSk0%2Fzc62t8GjV8tJgTTQPs4S3CKcAGoWyb7QfHVfzJc8qZ7EX4z5tPchXXwe2D%2FgcgOCDr0273z%2Fn5mqViWnwdpNoMsej1NJXvC9zHCDvFsDqx6cpUDJ9pFN%2FK4j4Vcl3X3cnqRtiWWiZajILNENJgJIlykAdYpYqu6Tl0yB6hxrkBaF%2B38Lv5vQrFxN2LXf4nOWWQQDMWL4utrj3K%2FOm0av%2B5R036cnMN6Luq6HLJy0jstyeEV5x%2F28KgTCppMFBIOPnmwwI77DTkBLIL7njK%2FdngkSHJPdjBdDSQtTo9SwIYFfsekCHsqEntreeg2%2FWgP0clvF0eANm5V%2BTcfjXDzIbXOnC5oPtMY8cEsxwwAuk712PT0ilVKpyV9vrHH9kzcGCrfHDIGAiNb6jxtKfqnOf9qmnb4yqiio0OQEZBO7GLx%2FPsMrTG5ay%2Bv0%2FSFKBlFVNP9nDW0%2BltjaYvr9I7Orct%2BYsixoCMFdsRrIvISJjtNrcEx8fWJEtqWO%2FMh2NE%2BhwSklLX%2BoPla8qcW1Mk36nsNWDKIp%2BiIsnzblU3JrSN2EKnSVA24BdIi%2BbkCVzkhCx4uoghTD9CpcPV%2FhrDi9XIvTYcF9dtPf9xTdD56UIHzCvhv9QWqZ9rC5SZ0IlofZ3IjLnunepC%2BLw%2FE%2BvFTTueSPJYqEoOzI7LSCHOoy%2Fe%2B1NoaB4WLb%2BLnUJ6%2BUfIRNPmN4X3ZBDPQgb9%2FU8HInkhRVXzvCl9l%2FqmMC9oTslVkVla0FdKDmfMOHYZ0J6il1HqKdnBQddsV4jyJteEXw9FChsWipuuXnWpL0kh0Fof3WwK6AEGRklnXsfcg96HTIOKl8qbmxzUmxES7x9%2FIl9d5MEYL3HRIhViIa8Ib0ShrxuKWqYxVvwn7YKbsHRJwLQJ6V%2BtjTcEkigiCwZ097nV4KIdTWqF44s1IM6jsVjZnxIq6YNbFhPjLUmtexDkdswk8gSypO%2F6S%2Fuc5ZsRaLc4sVfKXLUr4tArtgZalM4q9%2FXhqKz6%2BTaZEet6swNC%2BTyBpkT3rnYlLxOlmZwCPAqrVO%2Fh21%2FkTI%2F2eDCjDKPMKDV3Yn44kqI0iu9QKvq9vpKhWpL0qwdasPCCbpNqqDm2a%2BYSJiUj1lIzR5aPVjhytjxGof8wvzOPMC%2FwycIOfylpYt5yLyCOtiyyRjsjk5UCDXJ7C85n9QiSsk4YamIOsK9eTU4RZWiUE%2FcN9kMUWXjK6VIqdaGzHG7bZ0UlCrN8bg0Z1yldR8xuhqHqERzBF9k1utElo7X0jgnBowtOfbrUEnRmvv53cWw9S708L23hn%2BbuXm1wAwNzhjtzwQ0aZY3Q9rUOIPr4o1k6j%2BO%2FBtLocGjg81NER0sOSOOeNk8%2BPJffGRDEPCVqCJwMqB4fUeuHX0IbWRQ5aEN1QspnP3OIZtCiz%2FTj5Ep1%2FFkA8pos6UrRPDdfn12NgtmyETz3pBtNf324FkcujhUgrbWAdOaeOeT6cWoxmBlH8Z0SlmsPbQ7crgc4YePdOHVWJDXnaJaeAYRNTKG%2BFWjBl%2FN9M0RdYNi2LWCYHfppLu96p7onMS8K9Gxbv6MmIqIkphWdGREZkc7MzV3QQ0v6ZT666lMIdZOJ0YBqb19BpWNpEjRbA6U4P1%2BBfwsRMCyTVaQfb7n4%2Fdg5ndlzfEDUTrCsepkjdNPOz8OoTV6ZLw1Jm6GQqYNCQR4%2F5Mob6xseU3EbN4iZwBcJgo%2FiJfM2u6WCE8%2FEBNQ6MrieiRDnKTrrU8SI2w0KbmJxWGcDjYpMttH3QwuL%2FjwukpABX%2F0r2xjy3pNDMjyS00N%2BnO1A%2FcLFy2cgDJtdFsA%2ByN5BYdESZjMzOIsEtFs6lrOSDKzvVs24F6s%2BUAcqUwSDdaGFWtDWxG%2BCG02m8IQIvEsEgVR%2FAL4g45lUtCwlMzxi6jElpPPb31m%2BlvQEor7%2BHxSTXXwnLCuUvsKm2BvHPRp%2BvQZlqJY33oTUfkKKYXBHJLWBGVpyspTNYQqfxCqprkzifmRpxyZUhi7csXL8JmCLg%2Bq9Ahm5%2B5EAJDr%2FygH1uMDb6s2p7CPV0rpypJjvSJCYLaoli2eenxWDNQDYhZHFbm7lBUPRwyO648jsmzWHIYOki2YzZC%2BD%2BwtDomoYdwtx16kYuu%2FwLlVsv2U8vF4W7nstWkJjBmSqt4TXJXI6%2B0jRlyavMqS2N57ZVv8wwgGDxtZcaFlRGg6KgrrNXFXjVYC98LBauAbFk2z495OWWV6pxucuK7vb0w4vckz4RPUSv0xxLVbFy8CmG0hxE0m%2Bzyr8Hw5dEuN4RSgOJPu0uqx2BTzyyqhlhnSBeC61DHLMaYuBXrsIyf7G%2FDxxtH2Mg2UAvzT59uBmOVLDDaPY%2BLCdS2BUb%2BvCz%2FyI3pUyYkg8JfutGLdWm9rifg8%2BoA2eeadbROZecoU%2B%2F37yceATWCL2AlwXaBc%2BSDKy91GLgbclFu%2FzUUbrT7WBa0xZhM%2B%2B0WakSZUXrGnUDUSxowmYvi5pcIHv7KcFRb4rrgd%2Bx7b4VePpeSX6Asstc5y3qjaW4%2F599RttvBz0TUzilDXxVY5Zd2TM%2B9ax8qu63Ud8grLUYcEDA3Z';
        	HttpService.Get(url1, function (response) {
            	
            	if(response)
            		{
            		
            	//	vm.data = response.data.AccountDetailsResponse.Account;
            		//alert("data is : " + vm.data);
            		 //vm.authToken = response.headers('authToken');
            		//var test = response;
            		alert("json stringify " + JSON.stringify(response));
            		 //alert("data is : " + response.status + " response.. : " + test.AccountDetailsResponse);            		 
               		}
            	else{
            		alert("failing");
            		FlashService.Error(response.message);
                    vm.dataLoading = false;	
            	}

            });
        };
        
        initController();

        function initController() {
            loadCurrentUser();
            loadAllUsers();
        }

        function loadCurrentUser() {
        	
        	 vm.username1 = $rootScope.globals.currentUser.username;
            UserService.GetByUsername($rootScope.globals.currentUser.username)
                .then(function (user) {
                    vm.user = user;
                   
                });
        }

        function loadAllUsers() {
        	 vm.username1 = $rootScope.globals.currentUser.username;
            UserService.GetAll()
                .then(function (users) {
                    vm.allUsers = users;
                    
                });
        }

        function deleteUser(id) {
            UserService.Delete(id)
            .then(function () {
                loadAllUsers();
            });
        }
    }

})();