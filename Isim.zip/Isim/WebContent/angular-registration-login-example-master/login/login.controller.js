﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('LoginController', LoginController);

    LoginController.$inject = ['$location', 'AuthenticationService', 'FlashService'];
    function LoginController($location, AuthenticationService, FlashService) {
        var vm = this;

        vm.login = login;
        vm.authToken = "";
        
        (function initController() {
            // reset login status
            AuthenticationService.ClearCredentials();
        })();

        function login() {
        	alert("clicked Login");
        	//vm.username = vm.username.replace(' ', '%20');
        //	vm.password = btoa(vm.password);
          //  vm.dataLoading = true;
        	vm.username = vm.username;
        	vm.password =vm.password;
            AuthenticationService.Login2(vm.username, vm.password, function (response) {
            	alert ("creds are : " + vm.username + " " + vm.password);
            	if(response)
            		{
            		 var authToken = response.data[0].version;
            		 alert("data is : " + response.data[0].instance_name); 
            		 alert("response is : " + response.status);
            		// AuthenticationService.SetCredentials(vm.username, vm.password, authToken);
            		 $location.path('/');
            		}
            	else{
            		alert("failing");
            		FlashService.Error(response.message);
                    vm.dataLoading = false;	
            	}

            });
            
            
        };
    }

})();
